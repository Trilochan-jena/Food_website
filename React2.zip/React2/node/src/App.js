import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from './pages/home';
import Contact from './pages/conatct';
import Menu from './pages/menu';
import About from './pages/about';
import Pagenotfound from './pages/pagenotfound';
import Layout from './componete/layout/layout';
function App() {
  return (
    <div>
      <BrowserRouter>
      <Layout />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/about' element={<About />} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/menu' element={<Menu />} />
          <Route path='*' element={<Pagenotfound />} />
        </Routes>

      </BrowserRouter>
    </div>
  );
}

export default App;
